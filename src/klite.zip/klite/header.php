<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Klite
 * @since Klite 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/assets/img/favicon.png" type="image/x-icon" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/lib/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>

	<script>
		var wpsite	=	{
			theme_url	: "<?php echo get_template_directory_uri(); ?>",
			site_url	: "<?php echo site_url(); ?>",
			env 		: "<?php echo WP_ENV; ?>",
			is_mobile	: "<?php echo (wp_is_mobile) ? true : false ?>"
		};
	</script>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">

	<!-- Main Header -->
	<header id="header" class="mainHeader">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" role="logo"><?php bloginfo( 'name' ); ?></a>

		<!-- Search Form -->
		<form class="headerForm searchForm box" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
			<input type="text" id="head_search_field" class="input searchInput pull-left" name="s" value="" placeholder="Enter search term" />
			<input type="submit" class="submit searchLink pull-left disabled" value="Search" />
			<p class="error" id="top_search_error" style="display: none;" role="alert">Enter Search Term</p>
		</form>
	</header>

	<!-- Main Container -->
	<main id="main" class="mainContainer" role="main">
