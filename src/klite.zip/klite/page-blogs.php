<?php
// Template Name: Blogs

get_header(); ?>

<div id="maincontent" class="mainContent blogs">
    <?php
    // the query
    $wpb_all_query = new WP_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>12)); ?>

    <?php if ( $wpb_all_query->have_posts() ) : ?>

    <ul>

    	<!-- the loop -->
    	<?php while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); ?>

            <li>
                <?php if ( has_post_thumbnail() ) { ?>
                    <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php echo get_the_title(); ?>" /></a>
                <?php } ?>
                <h1><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h1>
                <?php
                    $content = get_the_content();
                    $content = wp_trim_letters($content, 90);
                ?>
                <p class="postDesc"><?php echo $content; ?></p>
            </li>
    	<?php endwhile; ?>
    	<!-- end of the loop -->

    </ul>
    <?php
        wp_reset_postdata();
    ?>

    <?php else : ?>
    	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
    <?php endif; ?>
</div>

<?php
get_footer();
?>
