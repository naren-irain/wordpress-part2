<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<div id="maincontent" class="mainContent search">
	<ul>
	<?php if ( have_posts() ) : ?>
			<?php
				// Start the loop.
				while ( have_posts() ) : the_post();
			?>
				<li>
					<?php if ( has_post_thumbnail() ) { ?>
						<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php echo get_the_title(); ?>" /></a>
					<?php } ?>
					<h1><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h1>
					<?php
						$content = get_the_content();
						$content = wp_trim_letters($content, 90);
					?>
					<p class="postDesc"><?php echo $content; ?></p>
				</li>
			<?php

				// End the loop.
				endwhile;

			// If no content, include the "No posts found" template.
			else :
				echo "No posts found";
			endif;
		?>
	</ul>
</div>

<?php get_footer(); ?>
