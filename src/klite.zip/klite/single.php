<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage klite
 * @since klite 1.0
 */

get_header(); ?>

<div id="maincontent" class="mainContent post">
<?php
	// Start the Loop.
	while ( have_posts() ) : the_post();

		// Post featured image
		if ( has_post_thumbnail() ) {
		?>
			<figure class="banner" role="banner">
				<picture>
					<source srcset="<?php the_post_thumbnail_url('banner-small'); ?>" media="(max-width: 750px)">
					<source srcset="<?php the_post_thumbnail_url('banner-big'); ?>" media="(min-width: 751px)">
					<img src="<?php the_post_thumbnail_url('banner-big'); ?>" data-big="<?php the_post_thumbnail_url('banner-big'); ?>" data-sm="<?php the_post_thumbnail_url('banner-small'); ?>" alt="<?php echo get_the_title(); ?>" />
				</picture>
			</figure>
		<?php
		// or add the_post_thumbnail( 'banner-big' ); if you don't need two different images srcset="'.get_the_post_thumbnail_url('banner-small').' 750w"
		}

		// Post title
		echo '<h1>'.get_the_title().'</h1>';
		echo '<time>'.get_the_time('jS F, Y').'</time>';

		// Post content
		echo '<div class="postContent">'.get_the_content().'</div>';

		// Previous/next post navigation.
		klite_post_nav();

		// Post tags
		echo '<h3>Tags</h3>';
		$tags = get_tags();
		$html = '<nav class="postTags">';
		foreach ( $tags as $tag ) {
			$tag_link = get_tag_link( $tag->term_id );

			$html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";
			$html .= "{$tag->name}</a> ";
		}
		$html .= '</nav>';
		echo $html;

		// Related posts
		echo '<h3>Related posts</h3>';
		wp_related_posts();

	endwhile;
?>
</div>

<?php
get_footer();
?>
