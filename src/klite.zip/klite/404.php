<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage klite
 * @since klite 1.0
 */

get_header(); ?>

<div id="maincontent" class="mainContent 404">
	<div class="row">
		<div class="pull-left">
			<p class="grpTitle">Oops! That page can&rsquo;t be found.</p>
			<h1>404 Error</h1>
		</div>
	</div>
</div>

<?php get_footer(); ?>
