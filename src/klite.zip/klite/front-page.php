<?php
/**
 * Home page template file
 */

get_header(); ?>

<div id="maincontent" class="mainContent front">
    <?php
		// Start the Loop.
		while ( have_posts() ) : the_post();

			// Post content
			echo '<div class="postContent">'.the_content().'</div>';

		endwhile;
	?>
</div>

<?php
get_footer();
?>
