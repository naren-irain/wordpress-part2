/* global screenReaderText */
/**
 * Theme functions file.
 *
 * Contains handlers for navigation and widget area.
*/

( function( $ ) {

	var picture_orientation	= true, prev_ww, picture_support = !!window.HTMLPictureElement;

	$( document ).ready( function() {

		// Search Form Enable Submit on text enter
		$('.searchInput').on('input', function(){
			if($(this).val() == '')
				$(this).next().addClass('disabled');
			else {
				$(this).next().removeClass('disabled');
				$('#top_search_error').hide();
			}
		});

		// Search form error throwing on empty entry
		$(document).on('click', '.searchLink.disabled', function(e){
			e.preventDefault();
			$('#top_search_error').show();
		});

		// Resize functions
		window.onresize	= function() {
			if((prev_ww <= 750 && window.innerWidth > 750) || (prev_ww > 750 && window.innerWidth <= 750))
				picture_orientation		=	true;

			if(picture_orientation && !picture_support && $('picture img').length > 0) {
				$('picture img').each(function(){
					$(this).prop('src', (window.innerWidth <= 750) ? $(this).data('sm') : $(this).data('big'));
				});
				prev_ww = window.innerWidth;
				picture_orientation	= false;
				console.log('in');
			}
		};
		window.onresize();

	});

} )( jQuery );
