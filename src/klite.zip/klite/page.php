<?php
/**
 * The template for displaying all pages
 * This is the template that displays all pages by default.
 */

get_header(); ?>

<div id="maincontent" class="mainContent page">
	<?php
		// Start the Loop.
		while ( have_posts() ) : the_post();

			// Post featured image
			if ( has_post_thumbnail() ) {
			?>
				<figure class="banner" role="banner">
					<picture>
						<source srcset="<?php the_post_thumbnail_url('banner-small'); ?>" media="(max-width: 750px)">
						<source srcset="<?php the_post_thumbnail_url('banner-big'); ?>" media="(min-width: 751px)">
						<img src="<?php the_post_thumbnail_url('banner-big'); ?>" data-big="<?php the_post_thumbnail_url('banner-big'); ?>" data-sm="<?php the_post_thumbnail_url('banner-small'); ?>" alt="<?php echo get_the_title(); ?>" />
					</picture>
				</figure>
			<?php
			// or add the_post_thumbnail( 'banner-big' ); if you don't need two different images srcset="'.get_the_post_thumbnail_url('banner-small').' 750w"
			}

			// Post title
			echo '<h1>'.get_the_title().'</h1>';

			// Post content
			echo '<div class="postContent">'.get_the_content().'</div>';

		endwhile;
	?>
</div>



<?php
get_footer();
